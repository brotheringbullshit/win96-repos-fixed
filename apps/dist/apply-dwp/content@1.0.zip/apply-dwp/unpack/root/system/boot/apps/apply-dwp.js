class ApplyDWP extends w96.WApplication {
    constructor() {
        super();
    }

    async main(args) {
        super.main(args);
        let path = args[0];
        let [desktop, dwp] = await Promise.all([w96.FS.readstr("C:/system/config/desktop.json").then(JSON.parse),
                                                w96.FS.readstr(path).then(JSON.parse)]);
        if(!desktop.background) {
            desktop.background = {};
        }
        desktop.background.type = "iframe";
        desktop.background.bg = dwp.url;
        await w96.FS.writestr("C:/system/config/desktop.json", JSON.stringify(desktop));
        await w96.ui.Theme.reloadDesktop();
    }
}

registerApp("apply-dwp", ["dwp"], function(args) {
    return w96.WApplication.execAsync(new ApplyDWP(), args);
});