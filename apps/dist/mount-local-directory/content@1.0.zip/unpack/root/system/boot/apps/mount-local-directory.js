
class LocalFileSystem extends w96.fstype.FileSystemBase {
    constructor(prefix) {
        super(prefix);
        this.remote = true;
        this.readOnly = true;
        this.features = ["read-only", "remote"];
        this.volumeLabel = "Local";
        this.driverName = "Locally mounted directory";
        this._dirCache = new Map();
    }

    async _addDirContentsToCache(cacheMap, dir) {
        for await(let entry of dir.values()) {
            if (entry.kind === "file") {
                let fileHandle = await dir.getFileHandle(entry.name, {create: false});
                let file = await fileHandle.getFile();
                cacheMap.set(entry.name, {kind: "file", handle: fileHandle, size: file.size});
            } else if(entry.kind === "directory") {
                let subCache = new Map();
                let subDir = await dir.getDirectoryHandle(entry.name);
                await this._addDirContentsToCache(subCache, subDir);
                cacheMap.set(entry.name, {kind: "directory", cache: subCache, handle: subDir});
            } else {
                console.error("Unrecognized kind for", entry);
            }
        }
    }

    async init() {
        this._rootDirectory = await window.showDirectoryPicker();
        await this._addDirContentsToCache(this._dirCache, this._rootDirectory);
        this.volumeLabel = this._rootDirectory.name;
        alert(`Done mounting ${this._rootDirectory.name}!`);
    }

    async uninit() {
        console.log("TODO: uninit");
    }

    _pathToList(path) {
        if(path === "/") {
            return [];
        } else {
            return path.split("/").slice(1);
        }
    }

    _getEntry(dirs) {
        let result = {kind: "directory", cache: this._dirCache, handle: this._rootDirectory};
        for(let dir of dirs) {
            result = result.cache?.get(dir);
        }
        return result;
    }

    exists(path) {
        return !!this._getEntry(this._pathToList(path));
    }

    filetype(path) {
        let entry = this._getEntry(this._pathToList(path));
        if(!entry) {
            return -1;
        } else if(entry.kind === "directory") {
            return 1;
        } else if(entry.kind === "file") {
            return 0;
        } else {
            return -1;
        }
    }

    isEmpty(path) {
        let entry = this._getEntry(this._pathToList(path));
        return entry.size === 0;
    }

    isFile(path) {
        return this.filetype(path) === 0;
    }

    async readbin(path) {
        let entry = this._getEntry(this._pathToList(path));
        let file = await entry.handle.getFile();
        return new Uint8Array(await file.arrayBuffer());
    }

    readdir(path) {
        let entry = this._getEntry(this._pathToList(path));
        if(path === "/") {
            path = "";
        }
        return Array.from(entry.cache.keys()).map(subdir => `${path}/${subdir}`);
    }

    async readstr(path) {
        let entry = this._getEntry(this._pathToList(path));
        let file = await entry.handle.getFile();
        return await file.text();
    }

    stat(path) {
        let entry = this._getEntry(this._pathToList(path));
        return {
            length: entry.size
        };
    }







    
}

class MountLocalDirectory extends w96.WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        let lfs = new LocalFileSystem(w96.FS.nextLetter());

        w96.FS.mount(lfs);


         
    }
}

w96.sys.reg.registerApp("mount-local-directory", [], function(args) {
	return w96.WApplication.execAsync(new MountLocalDirectory(), args);
});