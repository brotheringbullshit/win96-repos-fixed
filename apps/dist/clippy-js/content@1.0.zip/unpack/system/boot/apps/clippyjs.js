const { register } = w96.app;
const { Theme } = w96.ui;

// Icon from https://icon-sets.iconify.design/mdi/clippy/

const ICON_32 = "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20width%3D%2232%22%20height%3D%2232%22%20preserveAspectRatio%3D%22xMidYMid%20meet%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20d%3D%22M15%2015.5a2.5%202.5%200%200%201-2.5%202.5a2.5%202.5%200%200%201-2.5-2.5v-1.75a.75.75%200%200%201%20.75-.75a.75.75%200%200%201%20.75.75v1.75a1%201%200%200%200%201%201a1%201%200%200%200%201-1v-3.61c-.87-.28-1.5-1.02-1.5-1.89c0-1.1%201-2%202.25-2s2.25.9%202.25%202c0%20.87-.63%201.61-1.5%201.89v3.61M8.25%208c1.25%200%202.25.9%202.25%202c0%20.87-.63%201.61-1.5%201.89v5.36a3.25%203.25%200%200%200%203.25%203.25a3.25%203.25%200%200%200%203.25-3.25v-3.5a.75.75%200%200%201%20.75-.75a.75.75%200%200%201%20.75.75v3.5A4.75%204.75%200%200%201%2012.25%2022a4.75%204.75%200%200%201-4.75-4.75v-5.36C6.63%2011.61%206%2010.87%206%2010c0-1.1%201-2%202.25-2m1.81-1.87l-.43%201.46c-.41-.22-.88-.34-1.38-.34c-.91%200-1.72.4-2.22%201.02l-1.2-.9C5.46%206.57%206.41%206%207.5%205.81v-.06A3.75%203.75%200%200%201%2011.25%202A3.75%203.75%200%200%201%2015%205.75v.06c1.09.19%202.04.76%202.67%201.56l-1.2.9c-.5-.62-1.31-1.02-2.22-1.02c-.5%200-.97.12-1.38.34l-.43-1.46c.33-.13.69-.26%201.06-.32v-.06c0-1.25-1-2.25-2.25-2.25S9%204.5%209%205.75v.06c.37.06.73.19%201.06.32m4.19%203.12c-.55%200-1%20.34-1%20.75s.45.75%201%20.75s1-.34%201-.75s-.45-.75-1-.75m-6%200c-.55%200-1%20.34-1%20.75s.45.75%201%20.75s1-.34%201-.75s-.45-.75-1-.75z%22%20fill%3D%22currentColor%22%2F%3E%3C%2Fsvg%3E";
const ICON_16 = "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20width%3D%2216%22%20height%3D%2216%22%20preserveAspectRatio%3D%22xMidYMid%20meet%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20d%3D%22M15%2015.5a2.5%202.5%200%200%201-2.5%202.5a2.5%202.5%200%200%201-2.5-2.5v-1.75a.75.75%200%200%201%20.75-.75a.75.75%200%200%201%20.75.75v1.75a1%201%200%200%200%201%201a1%201%200%200%200%201-1v-3.61c-.87-.28-1.5-1.02-1.5-1.89c0-1.1%201-2%202.25-2s2.25.9%202.25%202c0%20.87-.63%201.61-1.5%201.89v3.61M8.25%208c1.25%200%202.25.9%202.25%202c0%20.87-.63%201.61-1.5%201.89v5.36a3.25%203.25%200%200%200%203.25%203.25a3.25%203.25%200%200%200%203.25-3.25v-3.5a.75.75%200%200%201%20.75-.75a.75.75%200%200%201%20.75.75v3.5A4.75%204.75%200%200%201%2012.25%2022a4.75%204.75%200%200%201-4.75-4.75v-5.36C6.63%2011.61%206%2010.87%206%2010c0-1.1%201-2%202.25-2m1.81-1.87l-.43%201.46c-.41-.22-.88-.34-1.38-.34c-.91%200-1.72.4-2.22%201.02l-1.2-.9C5.46%206.57%206.41%206%207.5%205.81v-.06A3.75%203.75%200%200%201%2011.25%202A3.75%203.75%200%200%201%2015%205.75v.06c1.09.19%202.04.76%202.67%201.56l-1.2.9c-.5-.62-1.31-1.02-2.22-1.02c-.5%200-.97.12-1.38.34l-.43-1.46c.33-.13.69-.26%201.06-.32v-.06c0-1.25-1-2.25-2.25-2.25S9%204.5%209%205.75v.06c.37.06.73.19%201.06.32m4.19%203.12c-.55%200-1%20.34-1%20.75s.45.75%201%20.75s1-.34%201-.75s-.45-.75-1-.75m-6%200c-.55%200-1%20.34-1%20.75s.45.75%201%20.75s1-.34%201-.75s-.45-.75-1-.75z%22%20fill%3D%22currentColor%22%2F%3E%3C%2Fsvg%3E";

const AGENTS = ["Bonzi",
                "Clippy",
                "F1",
                "Genie",
                "Genius",
                "Links",
                "Merlin",
                "Peedy",
                "Rocky",
                "Rover"];

class ClippyJS extends w96.WApplication {
    constructor() {
        super();
    }

    load() {
        return new Promise(resolve => {
            let script = document.createElement("script");
            script.type = "application/javascript";
            script.src = "https://unpkg.com/clippy.js@1.0.0/build/clippy.min.js";
            document.body.append(script);
            let css = document.createElement("link");
            css.rel = "stylesheet";
            css.type = "text/css";
            css.href = "https://unpkg.com/clippy.js@1.0.0/build/clippy.css";
            css.media = "all";
            document.head.append(css);
            script.onload = resolve;
        });
    }
    
    async main(argv) {
        super.main(argv);

        if(!window.clippy) {
            await this.load();
        }
        
        const mainwnd = this.createWindow({
            title: "Clippy.JS",
            icon: ICON_16,
            initialHeight: 400,
            initialWidth: 640,
            body: `
                <div class="clippyjs-agents"></div>
                <hr>
                <form class="clippyjs-speech-form">
                <input type="text" class="w96-textbox clippyjs-speech"><input type="submit" class="w96-button" value="Speak">
                </form>
                <hr>
                <div class="clippyjs-anims"></div>
            `,
            center: true,
            taskbar: true
        }, true); // true specifies that this is an app window (main window)
        
        mainwnd.show();

        let app = this;

        let agentsDiv = mainwnd.getBodyContainer().querySelector(".clippyjs-agents");
        let animsDiv = mainwnd.getBodyContainer().querySelector(".clippyjs-anims");
        let speechInput = mainwnd.getBodyContainer().querySelector(".clippyjs-speech");

        mainwnd.getBodyContainer().querySelector(".clippyjs-speech-form").addEventListener("submit", function(event) {
            event.preventDefault();
            if(app.agent) {
                app.agent.speak(speechInput.value);
                speechSynthesis.speak(new SpeechSynthesisUtterance(speechInput.value));
            }
        });

        for(let agent of AGENTS) {
            let button = document.createElement("button");
            button.textContent = agent;
            button.classList.add("w96-button");
            button.addEventListener("click", function() {
                clippy.load(agent, async function(agent) {
                    if(app.agent) {
                        await new Promise(resolve => app.agent.hide(false, resolve));
                    }
                    app.agent = agent;
                    animsDiv.replaceChildren();
                    agent.show();
                    for(let animation of agent.animations()) {
                        let button = document.createElement("button");
                        button.textContent = animation;
                        button.classList.add("w96-button")
                        button.addEventListener("click", function() {
                            agent.play(animation);
                        });
                        animsDiv.append(button);
                    }
                })
            });
            agentsDiv.append(button);
        }
        
    }
}

register({
    command: "clippy-js",
    type: "gui",
    cls: ClippyJS,
    meta: {
        icon: ICON_32,
        friendlyName: "Clippy.JS"
    }
});